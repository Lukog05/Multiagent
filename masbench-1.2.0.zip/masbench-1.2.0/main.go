package main

import (
	"masbench/cmd"
)

func main() {
	cmd.Execute()
}
